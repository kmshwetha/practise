package com.Demo.ConsumeAPI;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
//@RequestMapping("/send")
public class ConsumeService {


    @RequestMapping("/restdemo")
    public String method()
    {
        final String uri="https://jsonplaceholder.typicode.com/posts?id=4";
        //for(int i=0;i<=4;i++) {
        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.getForObject(uri, String.class);

        //System.out.println("API Random Result count "+ i +"----"+ result);
        System.out.println("jsonplaceholder Result----"+ result);
        return result;
    }
}
